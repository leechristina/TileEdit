g++ main.cpp $(pkg-config --cflags --libs sdl2) -lSDL2_ttf -lSDL2_image -Wno-write-strings
